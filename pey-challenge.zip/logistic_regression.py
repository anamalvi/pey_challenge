import csv
import numpy as np
from sklearn.linear_model import LogisticRegression

# file name constants
train_file = "census_data/census_train.csv"
train_file_mod = "census_data/census_train_drop.csv"
test_file = "census_data/census_test.csv"
test_file_mod = "census_data/census_test_drop.csv"

def write_mod_file(input_f, output_f):
	with open(input_f, "r") as in_file, open(output_f, "w") as out_file:
		reader = csv.reader(in_file)
		writer = csv.writer(out_file)
		next(reader)
		for row in reader:
			del row[2]
			writer.writerow(row)

# drop 3rd column and create modified files
write_mod_file(train_file, train_file_mod)
write_mod_file(test_file, test_file_mod)

lr = LogisticRegression()

# training with data 
training_data = np.genfromtxt(train_file_mod, delimiter=",")
x_training_vector = training_data[:, :-1]
y_target_vector = training_data[:, -1]
lr = lr.fit(x_training_vector, y_target_vector)

# testing on data
test_data = np.genfromtxt(test_file_mod, delimiter=",")
x_test_sample = test_data[:, :-1]
y_expected = test_data[:, -1]
score = lr.score(x_test_sample, y_expected)

# display mean accuracy score
print (score)
